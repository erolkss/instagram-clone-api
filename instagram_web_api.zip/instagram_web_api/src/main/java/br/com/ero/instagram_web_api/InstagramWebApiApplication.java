package br.com.ero.instagram_web_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstagramWebApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(InstagramWebApiApplication.class, args);
	}

}
